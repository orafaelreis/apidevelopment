module.exports = {
	settings : {
		host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'cultura',
    port: '8889'
	}
}
