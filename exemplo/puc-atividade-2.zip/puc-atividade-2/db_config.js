module.exports = {
	settings : {
		host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'brasucas',
    port: '8889'
	}
}
