var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

var ufController = require('./public/controllers/uf.js');
var personalityController = require('./public/controllers/personality.js');


var port = process.env.PORT || 3000;


app.listen( port, function() {
	'use strict';
	console.log( 'Listening on port ' + port );
} );


app.get('/', function(req, res) {
  res.send('server is running');
});

app.get('/ufs', function(req, res) {
	ufController.list(function(resp) {
		res.status(200).json(resp);
	});
});


app.get('/uf/:id', function(req, res) {
	var id = req.params['id']
	ufController.read(id,function(resp) {
    res.status(resp.statusCode).json(resp.responseData);
  });
});


app.get('/personality', function(req, res) {
	personalityController.findAll(function(resp) {
		res.status(200).json(resp);
	});
});


app.get('/personality/:id', function(req, res) {
	var id = req.params['id']
	personalityController.findByID(id,function(resp) {
		res.status(200).json(resp);
	});
});

app.post('/personality', function(req, res) {
  var helper = require('./public/util/DateHelper.js')

	var data = req.body;
	var personality = [data['name'],
    data['full_name'],
    helper.sqlDefaultDateFormat(data.birth),
    data['cityId'],
    data['photo_url']
  ];
	personalityController.insert(personality,
    function(resp) {
		res.json(resp);
	});
});
