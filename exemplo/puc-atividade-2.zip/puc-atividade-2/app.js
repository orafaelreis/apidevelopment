var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

var port = process.env.PORT || 3000;
app.listen( port, function() {
	'use strict';
	console.log( 'Listening on port ' + port );
} );


//controllers
var ufController = require('./public/controllers/uf.js');
var personalityController = require('./public/controllers/personality.js');



//router
app.get('/', function(req, res) {
  res.send('server is running...');
});

app.get('/ufs', function(req, res) {
	ufController.list(function(resp) {
		res.status(resp.statusCode).json(resp);
	});
});


app.get('/uf/:name', function(req, res) {
	var slug = req.params['name'];
	ufController.readBySlug(slug,function(resp) {
    res.status(resp.statusCode).json(resp);
  });
});


app.get('/personalities', function(req, res) {
	personalityController.findAll(function(resp) {
		res.status(resp.statusCode).json(resp);
	});
});

//GET personality/machado-de-assis
app.get('/personality/:name', function(req, res) {
  var nameSlug = req.params['name'];

 personalityController.findBySlug(nameSlug, function(resp) {
		res.status(resp.statusCode).json(resp);
	});
});

app.get('/uf/:slug/personalities', function(req, res) {
	var ufSlug = req.params['slug'];
	personalityController.findByUFSlug(ufSlug,function(resp) {
		res.status(resp.statusCode).json(resp);
	});
});


app.post('/personality', function(req, res) {
  var helper = require('./public/util/DateHelper.js')

	var data = req.body;
	var personality = [
    data['slug'],
    data['name'],
    data['fullName'],
    helper.sqlDefaultDateFormat(data.birth),
    data['cityId'],
    data['photoUrl']
  ];

  var achievements = data['achievements'];
  var knowledges = data['knowledges'];
  var awards = data['awards'];

  // console.log(personality);

	personalityController.insert(personality, knowledges, awards, achievements,
    function(resp) {
		    res.status(resp.statusCode).json(resp);
	});
});
