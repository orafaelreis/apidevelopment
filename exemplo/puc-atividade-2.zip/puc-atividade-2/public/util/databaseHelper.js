var db = require('../../db_config.js');
var mysql = require('mysql');

var DatabaseHelper = {};

DatabaseHelper.query = function(sql, params, releaseOrDestroy, callback){
  var pool = mysql.createPool(db.settings);

  pool.getConnection(function(err, connection) {
    sql = mysql.format(sql, params);
    console.log(sql);
		if (err){
      callback(err, null); return;
    }

    connection.query(sql, function(err, result, fields) {
      if(releaseOrDestroy == 'release'){
        connection.release();
      }else {
        connection.destroy();
      }
      if (err){
        callback(err, null); return;
      }
      callback(null, result);
    });
  });
}


module.exports = DatabaseHelper;
