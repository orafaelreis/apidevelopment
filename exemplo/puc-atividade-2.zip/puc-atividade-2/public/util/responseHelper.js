var responseHelper = {};

responseHelper.formatResponse = function(statusCode,responseData){
  return {
    statusCode: statusCode,
    responseData: responseData
  };
}

responseHelper.error = function(statusCode){
  var message = "";
  if (statusCode == 404) {
    message = "Not Found!"
  }
  var dataError = {"error": {
    "statusCode": statusCode,
    "message": message
  }};
  return responseHelper.formatResponse(statusCode,dataError);
};

responseHelper.result = function(statusCode,data){
  var dataResult = {"result": data};
  return responseHelper.formatResponse(statusCode,dataResult);
};

module.exports = responseHelper;
