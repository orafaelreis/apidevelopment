var moment = require('moment');

var DateHelper = {};

DateHelper.sqlDefaultDateFormat = function(pt_br_date){
  return moment( pt_br_date, 'DD/MM/YYYY' ).format('YYYY-MM-DD')
}


module.exports = DateHelper;
