var db = require('../../db_config.js');
var mysql = require('mysql');
var response = require('../util/responseHelper.js');

var Personality = {};

//GET /personality - lista todas as personalidades
Personality.findAll = function(callback){
  var connection = mysql.createConnection(db.settings);

  connection.connect(function(err){
		if (err) return callback(err);
    connection.query('SELECT ID as id, Nome as name, NomeCompleto as fullName, DATE_FORMAT(DataNascimento, \'%d\/%m\/%Y\') as birth, \
    CidadeNascimentoID as cityId, fotoUrl as photoUrl FROM Personalidade', function(err, rows, fields) {
      connection.destroy();// release() se for realizar outra consulta;
      if (err) throw err;
      if (rows.length == 0){
        callback(response.error(404));
        return;
      }
      callback(response.result(200,rows));
    });
  });
};


//GET /personality/id - detalhes da personalidade
Personality.findByID = function(id, callback){
  var connection = mysql.createConnection(db.settings);

  connection.connect(function(err){
		if (err) return callback(err);

    var sql = 'SELECT  ID as id, Nome as name, NomeCompleto as fullName, DATE_FORMAT(DataNascimento, \'%d\/%m\/%Y\') as birth, \
    CidadeNascimentoID as cityId, fotoUrl as photoUrl,  as FROM Personalidade WHERE ID = ?';
		var params = [id];
		sql = mysql.format(sql, params);

    connection.query(sql,
     function(err, rows, fields) {
       connection.destroy();// release() se for realizar outra consulta;
       if (err) throw err;
       if (rows.length == 0){
         callback(response.error(404));
         return;
       }
       callback(response.result(200,rows));
    });
  });
};

//POST /personality - insere uma nova personalidade
Personality.insert = function(params, callback){
  var connection = mysql.createConnection(db.settings);

  connection.connect(function(err) {
  if (err) return callback(err);
  console.log(params);
  var sql = 'INSERT INTO Personalidade(Nome, NomeCompleto, DataNascimento, CidadeNascimentoID, fotoUrl) VALUES(?,?,?,?,?)';
  sql = mysql.format(sql, params);

  connection.query(sql, function(err, result, fields) {
    connection.destroy();// release() se for realizar outra consulta;
    if (err) throw err;
    if (rows.length == 0){
      callback(response.error(404));
      return;
    }
    console.log(result.insertId);

    Personality.findByID(result.insertId, callback);
  });

});
};



module.exports = Personality;
