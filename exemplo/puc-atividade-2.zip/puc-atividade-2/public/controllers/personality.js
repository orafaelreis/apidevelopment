var response = require('../util/responseHelper.js');
var database = require('../util/databaseHelper.js');

var Personality = {};

//GET /personality - lista todas as personalidades
Personality.findAll = function(callback){
  var sql = 'SELECT ID as id, Nome as name, NomeCompleto as fullName, DATE_FORMAT(DataNascimento, \'%d\/%m\/%Y\') as birth, \
    CidadeNascimentoID as cityId, fotoUrl as photoUrl FROM Personalidade';

  database.query(sql, null, 'destroy', function(err, rows) {
    if (rows.length == 0){
      callback(response.error(404));
      return;
    }
    callback(response.result(200,rows));
  });
};




//GET /personality?id - detalhes da personalidade
Personality.findBySlug = function(nameSlug, callback){

  var sql = 'SELECT p.ID as id, p.Nome as name, NomeCompleto as fullName, \
  DATE_FORMAT(DataNascimento, \'%d\/%m\/%Y\') as birth, \
    CidadeNascimentoID as cityId, c.Nome as cityName, fotoUrl as photoUrl FROM Personalidade p \
    INNER JOIN Cidade c ON (c.ID < 2) \
     WHERE Slug = ?';

    var params = [nameSlug];

  database.query(sql, params, 'destroy', function(err, rows) {
    if (err) {
        callback(response.error(501,err.message))
        return
    }

    if (rows.length == 0){
      callback(response.error(404));
      return;
    }

    var data = {
      "id": rows[0].id,
      "name": rows[0].name,
      "fullName": rows[0].fullName,
      "birth": rows[0].birth,
      "city": {
        id:rows[0].cityId,
        name: rows[0].cityName
      },
      "photoUrl": rows[0].photoUrl,
    }


    callback(response.result(200,data));
  });
};



//GET /personality?id - detalhes da personalidade
Personality.findByUFSlug = function(ufSlug, callback){

    var sql = 'SELECT count(*) as count FROM Estado WHERE Slug = ?';
    var params = [ufSlug];
    database.query(sql, params, 'release', function(err, rows) {
      if (rows[0].count == 0){
        callback(response.error(404));
        return;
      }

      sql = 'SELECT p.ID as id, p.Slug as slug, p.Nome as name, p.NomeCompleto as fullName, DATE_FORMAT(p.DataNascimento, \'%d\/%m\/%Y\') as birth, \
      c.ID as cityId, e.ID as ufId, p.fotoUrl as photoUrl  \
      FROM Personalidade p \
      INNER JOIN Cidade c ON (c.ID = p.CidadeNascimentoID) \
      INNER JOIN Estado e ON (e.ID = c.EstadoID) WHERE e.Slug = ?';

      database.query(sql, params, 'destroy', function(err, rows) {
         callback(response.result(200,rows));
      });
    });
};


//POST /personality - insere uma nova personalidade
Personality.insert = function(params, knowledges, awards, achievements, callback){
  // console.log(params);

  //inserir personalidade
  var sql = 'INSERT INTO Personalidade(Slug, Nome, NomeCompleto, DataNascimento, CidadeNascimentoID, fotoUrl) VALUES(?,?,?,?,?,?)';

  database.query(sql, params, 'release', function(err, result) {
      if (err) {
        console.log(err);
        if (err.code == 'ER_BAD_NULL_ERROR') {
            callback(response.error(400, err.message)); return
        }
        if (err.code == 'ER_DUP_ENTRY') {
            callback(response.error(409, err.message)); return
        }
        callback(response.error(500)); return;
      }

      var personality_id = result.insertId;
      console.log('personality_id = ' + personality_id);

      //inserir area de conhecimento (Obs: o Conhecimento já tem que estar cadastrado)
      sql = 'INSERT INTO PersonalidadeConhecimento(PersonalidadeID,ConhecimentoID) VALUES ?';
      params = [];
      for (var i = 0; i < knowledges.length; i++) {
        var arr = [personality_id, knowledges[i].id];
        params.push(arr);
      }

      database.query(sql, [params], 'release', function(err, result) {
        if (err) {
          console.log(err);
          callback(response.error(500)); return;
        }

        //TODO inserir premios (Obs: o Premio já tem que estar cadastrado)
        sql = 'INSERT INTO PersonalidadePremio(PersonalidadeID,PremioID, Ano) VALUES ?';
        params = [];
        for (var i = 0; i < awards.length; i++) {
          var arr = [personality_id, awards[i].id, awards[i].year];
          params.push(arr);
        }
        database.query(sql, [params], 'release', function(err, result) {
          if (err) {
            console.log(err);
            callback(response.error(500)); return;
          }

          //inserir feitos
          sql = 'INSERT INTO Feito(PersonalidadeID,Descricao) VALUES ?';
          params = [];
          for (var i = 0; i < achievements.length; i++) {
            var arr = [personality_id, achievements[i]];
            params.push(arr);
          }

          database.query(sql, [params], 'destroy', function(err, result) {
            if (err) {
              console.log(err);
              callback(response.error(500)); return;
            }

            //TODO retornar a entidade com os dados preenchidos
            callback(response.result(201, {}))

          });//end feitos
        });//end premios
      });//end conhecimentos
  });//end personalidade
};



module.exports = Personality;
