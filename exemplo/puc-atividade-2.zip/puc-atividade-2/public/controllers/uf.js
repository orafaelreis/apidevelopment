var response = require('../util/responseHelper.js');
var database = require('../util/databaseHelper.js');

//GET /ufs - lista as unidades federais
exports.list = function(callback){
  database.query('SELECT ID as id, Sigla as initials FROM Estado', null, 'destroy', function(err, rows){
    if (rows.length == 0){
      callback(response.error(404));
      return;
    }
    callback(response.result(200,rows));
  });
};


//GET /uf?id - detalhe da unidade federal
exports.readByID = function(id, callback){
  //dados do estado
  var sql = 'SELECT e.ID, e.Slug, e.Sigla FROM Estado e WHERE e.ID = ?';
  var params = [id];
  database.query(sql, params, 'release', function(ufRows){

    //dados das cidades e municipios
    sql = 'SELECT c.ID as id, c.Nome as name FROM Estado e INNER JOIN Cidade c ON (c.EstadoID = e.ID) WHERE e.ID = ?';

    database.query(sql, params, 'destroy', function(citiesRows){
      if (citiesRows.length == 0){
        callback(response.error(404));
        return;
      }

      var data = {
        id: ufRows[0].ID,
        slug: ufRows[0].Slug,
        initials: ufRows[0].Sigla,
        cities: citiesRows
      };
      callback(response.result(200,data));
    });
  });
};


//GET /uf/slug - detalhe da unidade federal
exports.readBySlug = function(slug, callback){
    //dados do estado
    var sql = 'SELECT e.ID, e.Slug, e.Sigla FROM Estado e WHERE e.Slug = ?';
		var params = [slug];
    database.query(sql, params, 'release', function(err, ufRows){

      //dados das cidades e municipios
      sql = 'SELECT c.ID as id, c.Nome as name FROM Estado e INNER JOIN Cidade c ON (c.EstadoID = e.ID) WHERE e.Slug = ?';

      database.query(sql, params, 'destroy', function(err, citiesRows){
        if (citiesRows.length == 0){
          callback(response.error(404));
          return;
        }

        var data = {
          id: ufRows[0].ID,
          slug: ufRows[0].Slug,
          initials: ufRows[0].Sigla,
          cities: citiesRows
        };
        callback(response.result(200,data));
      });
    });
};
