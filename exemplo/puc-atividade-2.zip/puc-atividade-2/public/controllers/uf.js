var db = require('../../db_config.js');
var mysql = require('mysql');
var response = require('../util/responseHelper.js');

//GET /ufs - lista as unidades federais
exports.list = function(callback){
  var connection = mysql.createConnection(db.settings);

  connection.connect(function(err){
		if (err) return callback(err);
    connection.query('SELECT ID as id, Sigla as initials FROM Estado', function(err, rows, fields) {
      connection.destroy();// release() se for realizar outra consulta;
      if (err) throw err;
      if (rows.length == 0){
        callback(response.error(404));
        return;
      }
      callback(response.result(200,rows));
    });
  });
};


//GET /uf/id- detalhe da unidade federal
exports.read = function(id, callback){
  var connection = mysql.createConnection(db.settings);

  connection.connect(function(err){
		if (err) return callback(err);

    var sql = 'SELECT * FROM Estado WHERE ID = ? UNION (Select c.ID, c.Nome FROM Estado e \
    INNER JOIN Cidade c ON (c.EstadoID = e.ID) WHERE e.ID = ?)';
		var params = [id,id];
		sql = mysql.format(sql, params);

    connection.query(sql,
     function(err, rows, fields) {
      connection.destroy();// release() se for realizar outra consulta;
      if (err) throw err;
      if (rows.length == 0){
        callback(response.error(404));
        return;
      }

      var data = {
        id: rows[0].ID,
        initials: rows[0].Sigla,
        cities: rows.splice(1)
      };
      callback(response.result(200,data));
    });
  });
};
