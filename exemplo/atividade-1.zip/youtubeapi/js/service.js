var API_DOMAIN = "https://www.googleapis.com/youtube/v3/";
var API_KEY = "<CHAVE DE ACESSO DA API>";


var loadData = function(){
  var consulta = $("#consulta").val();
  console.log(consulta);

  var settings = {
  "async": true,
  "crossDomain": true,
  "url": API_DOMAIN+"search?q="+consulta+"&part=snippet&orderby=viewCount&key="+API_KEY,
  "method": "GET",
  "headers": {
    "cache-control": "no-cache",
  }
}

$.ajax(settings).done(function (response) {
  var data = response.items[0].snippet.title;
  var thumb = response.items[0].snippet.thumbnails.high.url;
  console.log(data);
  console.log(thumb);
});
}
